#!/bin/bash
echo "Por favor ingrese su nombre de usuario"
read
Hola, $, es un gran gusto saludarte

Listando con el comando ls, en forma de lista:

sebastian@sebastian-VJFE52A0111H:~/Documentos/SebastianNavarroIMT-231/test_1/primerParcial231$ ls tarea3
basicScript.sh  basicSript.sh  fechatarea3.txt  ubicaciones
