#!/bin/bash
echo " Ingrese su nombre de usuario"
read
echo "Hola ,$, te envío un saludo fraterno"

